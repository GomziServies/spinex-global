


function Parent(){
    return(
        <>
            <div class="center parent">
                <h1>Parents info</h1>
             
                    <div class="txt_field">
                        <input type="text" required />
                        <span></span>
                        <label>Father name</label>
                    </div>
                    <div class="txt_field">
                        <input type="contect" required />
                        <span></span>
                        <label>Father contect no.</label>
                    </div>
                    <div class="txt_field">
                        <input type="occupation" required />
                        <span></span>
                        <label>Occupation</label>
                    </div>
                    <div class="txt_field">
                        <input type="text" required />
                        <span></span>
                        <label>Mother name</label>
                    </div>
                    <div class="txt_field">
                        <input type="contect" required />
                        <span></span>
                        <label>Mother contect no.</label>
                    </div>
                   
                
            </div>
        </>
    )
}

export default  Parent;