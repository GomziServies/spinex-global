

function Academic() {
    return (
        <>
            <div class="center academic">
                <h1>Academic details</h1>
            
                    <div class="txt_field">
                        <input type="year" required />
                        <span></span>
                        <label>select your course</label>
                    </div>
                    <div class="txt_field">
                        <input type="" required />
                        <span></span>
                        <label>Pass out year</label>
                    </div>
                    
                    <input type="submit" value="Submit" />

            </div>

        </>
    )
}

export default Academic;