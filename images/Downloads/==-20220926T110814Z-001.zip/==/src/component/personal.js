import Filecomponent from "./filecomponent";

function Personal() {
    return (
        <>
            <div class="center">
                <h1>Personal info</h1>

                <Filecomponent label="Username" />
               
                    {/* <div class="txt_field">
                        <input type="text" required />
                        <span></span>
                        <label>Username</label>
                    </div> */}
                    <div class="txt_field">
                        <input type="email"  />
                        <span></span>
                        <label>Email</label>
                    </div>
                    <div class="txt_field">
                        <input type="Mobile" required />
                        <span></span>
                        <label>Mobile</label>
                    </div>
                    <div class="txt_field">
                        <input type="" required />
                        <span></span>
                        <label>Date of birth</label>
                    </div>
                    
             
            </div>
        </>
    )
}

export default Personal;