import logo from './logo.svg';
import './App.css';
import Parent from './component/parents';
import Academic from './component/academic';
import Personal from './component/personal';

function App() {
  return (
    <form method="post">
    <Parent />
    <Academic />
    <Personal />
    </form>
  )
}

export default App;
