

function Filecomponent(props){
    return(
        <div class="txt_field">
                        <input type={props.type} required />
                        <span></span>
                        <label>{props.label}</label>
                    </div>
    );
}

export default Filecomponent;